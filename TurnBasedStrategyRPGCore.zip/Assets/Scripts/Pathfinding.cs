using System;
using System.Collections.Generic;
using UnityEngine;

public class Pathfinding : MonoBehaviour
{
    public static Pathfinding Instance { get; private set; }
    
    private const int MOVE_STRAIGHT_COST = 10;
    private const int MOVE_DIAGONAL_COST = 10;
    
    [SerializeField] private Transform gridDebugObjectPrefab;
    [SerializeField] private LayerMask obstaclesLayerMask;
    

    private int width;
    private int height;
    private float cellSize;
    private GridSystem<PathNode> gridSystem;

    private void Awake()
    {
        if (Instance != null)
        {
            Debug.LogError("There is already a Pathfinding in the scene!");
            Destroy(gameObject);
        }
        Instance = this;
    }

    public void Setup(int width, int height, float cellSize)
    {
        this.width = width;
        this.height = height;
        this.cellSize = cellSize;
        
        gridSystem = new GridSystem<PathNode>(this.width, this.height, this.cellSize,
            (GridSystem<PathNode> g, GridPosition gridPosition) => new PathNode(gridPosition));
        
        // Ya no instanciamos objetos de debug del pathfinding para evitar errores de casteo
        // gridSystem.CreateDebugObjects(gridDebugObjectPrefab);

        for (int x = 0; x < this.width; x++)
        {
            for (int z = 0; z < this.height; z++)
            {
                GridPosition gridPosition = new GridPosition(x, z);
                Vector3 worldPosition = LevelGrid.Instance.GetWorldPosition(gridPosition);
                float raycastOffsetDistance = 5f;
                if (Physics.Raycast(worldPosition + Vector3.down * raycastOffsetDistance, Vector3.up,
                        raycastOffsetDistance * 2, obstaclesLayerMask))
                {
                    GetNode(x,z).SetWalkable(false);
                }
            }
        }
    }

    public List<GridPosition> FindPath(GridPosition startGridPosition, GridPosition endGridPosition, out int pathLength)
    {
        List<PathNode> openList = new List<PathNode>();
        List<PathNode> closedList = new List<PathNode>();

        PathNode startNode = gridSystem.GetGridObject(startGridPosition);
        PathNode endNode = gridSystem.GetGridObject(endGridPosition);
        
        openList.Add(startNode);

        for (int x = 0; x < gridSystem.GetWidth(); x++)
        {
            for (int z = 0; z < gridSystem.GetHeight(); z++)
            {
                GridPosition gridPosition = new GridPosition(x, z);
                PathNode pathNode = gridSystem.GetGridObject(gridPosition);

                pathNode.SetGCost(int.MaxValue);
                pathNode.SetHCost(0);
                pathNode.CalculateFCost();
                pathNode.ResetCameFromPathNode();
            }
        }
        
        startNode.SetGCost(0);
        startNode.SetHCost(CalculateDistance(startGridPosition, endGridPosition));
        startNode.CalculateFCost();

        while (openList.Count > 0)
        {
            PathNode currentNode = GetLowestFCostPathNode(openList);

            if (currentNode == endNode)
            {
                //Reached Final Node.
                pathLength = endNode.GetGCost();
                return CalculatePath(endNode);
            }
            
            openList.Remove(currentNode);
            closedList.Add(currentNode);

            foreach (PathNode neighbourNode in GetNeighbourList(currentNode))
            {
                if (closedList.Contains(neighbourNode)) continue;
                if (!neighbourNode.IsWalkable())
                {
                    closedList.Add(neighbourNode);
                    continue;
                }
                
                int tentativeGCost = currentNode.GetGCost() + CalculateDistance(currentNode.GetGridPosition(), neighbourNode.GetGridPosition());

                if (tentativeGCost < neighbourNode.GetGCost())
                {
                    neighbourNode.SetCameFormPathNode(currentNode);
                    neighbourNode.SetGCost(tentativeGCost);
                    neighbourNode.SetHCost(CalculateDistance(neighbourNode.GetGridPosition(), endGridPosition));
                    neighbourNode.CalculateFCost();

                    if (!openList.Contains(neighbourNode))
                    {
                        openList.Add(neighbourNode);
                    }
                }
            }
        }
        
        //No path found.
        pathLength = 0;
        return null;
    }

    public int CalculateDistance(GridPosition gridPositionA, GridPosition gridPositionB)
    {
        GridPosition gridPositionDistance = gridPositionA - gridPositionB;
        int xDistance = Mathf.Abs(gridPositionDistance.x);
        int zDistance = Mathf.Abs(gridPositionDistance.z);
        int remaining = Mathf.Abs(xDistance - zDistance);
        return MOVE_DIAGONAL_COST * Mathf.Min(xDistance, zDistance) + MOVE_STRAIGHT_COST * remaining;
    }

    private PathNode GetLowestFCostPathNode(List<PathNode> pathNodeList)
    {
        PathNode lowestFCostPathNode = pathNodeList[0];
        for (int i = 0; i < pathNodeList.Count; i++)
        {
            if (pathNodeList[i].GetFCost() < lowestFCostPathNode.GetFCost())
            {
                lowestFCostPathNode = pathNodeList[i];
            }
        }
        return lowestFCostPathNode;
    }

    private PathNode GetNode(int x, int z)
    {
        return gridSystem.GetGridObject(new GridPosition(x, z));
    }
    
    private List<PathNode> GetNeighbourList(PathNode currentNode)
    {
        List<PathNode> neighbourList = new List<PathNode>();
        GridPosition gridPosition = currentNode.GetGridPosition();

        bool isOctagon = (gridPosition.x + gridPosition.z) % 2 == 0;

        // Conexiones en el eje X/Z del array (estos conectan a Rombos visualmente en diagonal)
        if (gridPosition.x - 1 >= 0) neighbourList.Add(GetNode(gridPosition.x - 1, gridPosition.z));
        if (gridPosition.x + 1 < gridSystem.GetWidth()) neighbourList.Add(GetNode(gridPosition.x + 1, gridPosition.z));
        if (gridPosition.z - 1 >= 0) neighbourList.Add(GetNode(gridPosition.x, gridPosition.z - 1));
        if (gridPosition.z + 1 < gridSystem.GetHeight()) neighbourList.Add(GetNode(gridPosition.x, gridPosition.z + 1));

        // Conexiones diagonales del array (estos conectan Octágonos entre sí, ortogonalmente en la vista)
        if (isOctagon)
        {
            if (gridPosition.x - 1 >= 0 && gridPosition.z - 1 >= 0) neighbourList.Add(GetNode(gridPosition.x - 1, gridPosition.z - 1));
            if (gridPosition.x - 1 >= 0 && gridPosition.z + 1 < gridSystem.GetHeight()) neighbourList.Add(GetNode(gridPosition.x - 1, gridPosition.z + 1));
            if (gridPosition.x + 1 < gridSystem.GetWidth() && gridPosition.z - 1 >= 0) neighbourList.Add(GetNode(gridPosition.x + 1, gridPosition.z - 1));
            if (gridPosition.x + 1 < gridSystem.GetWidth() && gridPosition.z + 1 < gridSystem.GetHeight()) neighbourList.Add(GetNode(gridPosition.x + 1, gridPosition.z + 1));
        }

        return neighbourList;
    }

    public List<GridPosition> GetReachableGridPositionList(GridPosition startGridPosition, int maxDistance)
    {
        List<GridPosition> reachableGridPositionList = new List<GridPosition>();

        PathNode startNode = gridSystem.GetGridObject(startGridPosition);

        Queue<PathNode> queue = new Queue<PathNode>();
        Dictionary<PathNode, int> distanceByNode = new Dictionary<PathNode, int>();

        queue.Enqueue(startNode);
        distanceByNode[startNode] = 0;

        while (queue.Count > 0)
        {
            PathNode currentNode = queue.Dequeue();
            int currentDistance = distanceByNode[currentNode];

            if (currentDistance >= maxDistance)
            {
                continue;
            }

            foreach (PathNode neighbourNode in GetNeighbourList(currentNode))
            {
                if (distanceByNode.ContainsKey(neighbourNode))
                {
                    continue;
                }

                GridPosition neighbourGridPosition = neighbourNode.GetGridPosition();

                if (!neighbourNode.IsWalkable())
                {
                    continue;
                }

                if (!LevelGrid.Instance.CanAddUnitAtGridPosition(neighbourGridPosition))
                {
                    continue;
                }

                int neighbourDistance = currentDistance + 1;

                distanceByNode[neighbourNode] = neighbourDistance;
                queue.Enqueue(neighbourNode);
                reachableGridPositionList.Add(neighbourGridPosition);
            }
        }

        return reachableGridPositionList;
    }

    private List<GridPosition> CalculatePath(PathNode endNode)
    {
        List<PathNode> pathNodeList = new List<PathNode> { endNode };
        PathNode currentNode = endNode;
        while (currentNode.GetCameFromPathNode() != null)
        {
            pathNodeList.Add(currentNode.GetCameFromPathNode());
            currentNode = currentNode.GetCameFromPathNode();
        }
        pathNodeList.Reverse();
        
        List<GridPosition> gridPositionList = new List<GridPosition>();
        foreach (PathNode pathNode in pathNodeList)
        {
            gridPositionList.Add(pathNode.GetGridPosition());
        }
        return gridPositionList;
    }

    public void SetIsWalkableGridPosition(GridPosition gridPosition, bool isWalkable)
    {
        gridSystem.GetGridObject(gridPosition).SetWalkable(isWalkable);
    }
    
    public bool IsWalkableGridPosition(GridPosition gridPosition)
    {
        return gridSystem.GetGridObject(gridPosition).IsWalkable();
    }

    public bool HasPath(GridPosition startGridPosition, GridPosition endGridPosition)
    {
        return FindPath(startGridPosition, endGridPosition, out _) != null;
    }

    public int GetPathLength(GridPosition startGridPosition, GridPosition endGridPosition)
    {
        FindPath(startGridPosition, endGridPosition, out int pathLength);
        return pathLength;
    }
}
